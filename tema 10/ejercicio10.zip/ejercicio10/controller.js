export const suma = (a,b) => {
    return a + b 
}

export const multiplica = (a,b) => {
    return a * b
}

